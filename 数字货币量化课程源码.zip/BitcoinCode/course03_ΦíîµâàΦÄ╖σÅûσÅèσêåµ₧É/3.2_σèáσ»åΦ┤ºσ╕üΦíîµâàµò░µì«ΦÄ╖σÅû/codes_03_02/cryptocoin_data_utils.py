import requests
import pandas as pd
from datetime import datetime


def get_single_ticker_data(symbol):
    """
        获取指定交易对的ticker数据

        参数：
            symbol: 交易对，如：btc_usdt
        返回：
            ticker_df: ticker数据的DataFrame对象
    """
    # 获取ticker数据，https://www.okex.com/api/v1/ticker.do
    ticker_url = 'https://www.okex.com/api/v1/ticker.do?symbol={}'.format(symbol)
    try:
        res_obj = requests.get(ticker_url, timeout=15)
    except Exception as e:
        print('错误！', e)
        return None

    ticker_df = None

    if res_obj.status_code == 200:
        json_obj = res_obj.json()
        if 'error_code' in json_obj:
            print('错误码:{}'.format(json_obj['error_code']))
        else:
            raw_df = pd.DataFrame(json_obj)

            ticker_df = pd.DataFrame(index=[0], columns=['datetime', 'symbol'] + raw_df.index.tolist())
            ticker_df['datetime'] = pd.to_datetime(datetime.utcnow())
            ticker_df['symbol'] = symbol.replace('_', '/').upper()
            ticker_df[raw_df.index.tolist()] = raw_df['ticker'].values
    else:
        print('数据获取失败，状态码:{}'.format(res_obj.status_code))

    return ticker_df


def get_single_kline_data(symbol, kline_type='1min', size=20000):
    """
        获取指定交易对的K线数据

        参数：
            symbol: 交易对，如：btc_usdt
            kline_type: K线频率，1min/3min/5min/15min/30min/1day/1week/1hour/2hour/4hour/6hour/12hour
            size: 记录个数
        返回：
            ticker_df: ticker数据的DataFrame对象
    """
    # 获取kline数据，https://www.okex.com/api/v1/kline.do
    kline_url = 'https://www.okex.com/api/v1/kline.do?symbol={}&type={}&size={}'\
        .format(symbol, kline_type, size)
    try:
        res_obj = requests.get(kline_url, timeout=15)
    except Exception as e:
        print('错误！', e)
        return None

    kline_df = None

    if res_obj.status_code == 200:
        json_obj = res_obj.json()
        if 'error_code' in json_obj:
            print('错误码:{}'.format(json_obj['error_code']))
        else:
            raw_df = pd.DataFrame(json_obj)

            kline_df = raw_df.copy()
            kline_df.columns = ['datetime', 'open', 'high', 'low', 'close', 'vol']
            kline_df['datetime'] = pd.to_datetime(kline_df['datetime'], unit='ms')
            kline_df['symbol'] = symbol.replace('_', '/').upper()

    else:
        print('数据获取失败，状态码:{}'.format(res_obj.status_code))

    return kline_df


def get_tickers_data(symbol_list):
    """
        获取多个交易对的ticker数据
    """
    tickers_df = pd.DataFrame()
    for symbol in symbol_list:
        ticker_df = get_single_ticker_data(symbol)
        if ticker_df is None:
            continue
        tickers_df = tickers_df.append(ticker_df)
    return tickers_df


def get_klines_data(symbol_list):
    """
        获取多个交易对的k线数据
    """
    klines_df = pd.DataFrame()
    for symbol in symbol_list:
        kline_df = get_single_kline_data(symbol, kline_type='1min', size=60)
        if kline_df is None:
            continue
        klines_df = klines_df.append(kline_df)
    return klines_df


