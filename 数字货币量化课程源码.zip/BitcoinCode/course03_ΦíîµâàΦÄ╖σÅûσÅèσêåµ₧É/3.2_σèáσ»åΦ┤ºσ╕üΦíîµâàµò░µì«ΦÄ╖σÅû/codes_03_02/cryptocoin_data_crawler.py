import pandas as pd

import cryptocoin_data_utils as cdu

pd.set_option('expand_frame_repr', False)


def main():
    """
        主函数
    """
    # == 获取单个交易对的信息
    symbol = 'btc_usdt'
    # ticker_df = cdu.get_single_ticker_data(symbol)
    # print(ticker_df)
    #
    kline_df = cdu.get_single_kline_data(symbol, kline_type='1day')
    print(kline_df.tail())
    kline_df.to_csv('./btc_usdt_day_price.csv', index=False)

    # # == 获取多个交易对的信息
    # symbol_list = ['btc_usdt', 'ltc_btc']
    # tickers_df = cdu.get_tickers_data(symbol_list)
    # print(tickers_df)

    # klines_df = cdu.get_klines_data(symbol_list)
    # print(klines_df)


if __name__ == '__main__':
    main()
