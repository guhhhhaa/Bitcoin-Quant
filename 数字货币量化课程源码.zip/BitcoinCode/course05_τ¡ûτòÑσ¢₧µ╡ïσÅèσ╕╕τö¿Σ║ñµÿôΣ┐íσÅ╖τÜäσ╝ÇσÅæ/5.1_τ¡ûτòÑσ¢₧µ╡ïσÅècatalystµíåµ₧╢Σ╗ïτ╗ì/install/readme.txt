Linux or MacOS Python 3.6:
conda env create -f python3.6-environment.yml
source activate catalyst


Windows Python 3.6:
conda env create -f python3.6-environment-windows.yml
activate catalyst

catalyst --version